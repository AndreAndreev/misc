#!/bin/sh

function pull {
	    docker pull $DOCKER_REPO$1
            docker tag $DOCKER_REPO$1 $1
            docker rmi $DOCKER_REPO$1
}

function print_usage {
    	    echo "Usage: ./pull.sh <image name:tag number> " 
}
if [ $# -eq 0 ] ; then
            print_usage
            exit 1
fi

pull $1














