#!/bin/sh

function push {
	    docker login -u $2 $DOCKER_REPO &&
            docker tag  $1 $DOCKER_REPO$1 &&
            docker push $DOCKER_REPO$1 &&
            docker rmi $DOCKER_REPO$1
}
function print_usage {
            echo "Usage: ./push.sh <image name: tag number> <inumber>" 
}
if [ $# -eq 0 ] ; then
       	    print_usage
       	    exit 1
fi
if [ -z $2 ] ; then
            print_usage
            exit 1
fi

push $1 $2


