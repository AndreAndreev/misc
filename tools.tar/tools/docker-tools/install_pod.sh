#!/bin/sh

function prompt_password {
    while true; do
        echo -n "    Enter password: " 
        read -s  password
        echo -e -n "\n    Reenter password: " 
        read -s  password_again
        if [ "$password" = "$password_again" ]; then
            echo -e "\n    Password set"
            break
        else
            echo -e "\n    Passwords did not match. Please try again"
        fi
    done
}

if [ -z "$1" ] || [ -z `echo $1 | grep '.*\.zip$'` ]; then
    echo "Usage: $0 [URL or FULL PATH OF COMPOSE.ZIP]"
    exit 1
fi

location="$1"

if [ -n "$(echo "$location" | grep '^http.*')" ]; then
    echo -n "User name: " 
    read userid
    echo -n "Password: " 
    read -s  password

    if [ -n "$userid" ]; then
        auth="$userid":"$password"
        curl "$location" -u $auth -o /tmp/cvp-compose.zip
    else
        curl "$location" -o /tmp/cvp-compose.zip
    fi

    # TODO add error check
    location=/tmp/cvp-compose.zip
fi

compose_dir=$HOME/Desktop/compose
mkdir -p $compose_dir

cd $compose_dir
unzip "$location"
if [ "$?" -ne 0 ]; then
    echo "Could not extract the file"
    exit 1
fi

last_addition=`ls -t -1 $HOME/Desktop/compose | grep -v default | head -n 1`
if [ -n "$last_addition" ] && [ -d "$compose_dir/$last_addition" ] ; then
    rm -f $compose_dir/default
    ln -s $compose_dir/$last_addition $compose_dir/default
    echo `ls -l $compose_dir/default`
fi
