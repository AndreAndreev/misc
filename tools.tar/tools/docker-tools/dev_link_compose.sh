#!/bin/sh

compose_dir=$HOME/Desktop/compose
mkdir -p $compose_dir

compose_path=`find  $GIT_HOME/vhppa-docker-repository/cvp-docker/cvp-compose/target -maxdepth 1 -type d -name 'cvp-docker-*' -print -quit`
if [ -n "$compose_path" ]; then
    # There will be exactly one entry
    version=`ls $compose_path`

    if [ -z "$version" ]; then
        echo "Did not find anything under $compose_path . Quitting"
        exit 1
    fi

    rm -f $compose_dir/default
    ln -s $compose_path/$version $compose_dir/default
else 
    echo "Could not find anything under $GIT_HOME/vhppa-docker-repository/cvp-docker/cvp-compose/target"
    exit 1
fi