#!/bin/sh

if [ "$#" -lt 3 ]; then
    echo "Usage: $0 [DIRECTORY] [FILENAME_PATTERN] [REALM]... "
    exit 1
fi

dir_name="$1"
pattern="$2"

files_to_drop=`ls -1 $dir_name/$pattern`


for realm in "${@:3}"; do
    for file in $files_to_drop; do
        time_now=`date '+%Y%m%d%H%M%S'`
        destination=$PERIMETER_LOC/sftp_root/${realm}/to_cg/${realm}_$time_now.txt
        echo "Copying $file to $destination"
        cp "$file" "$destination"
        sleep 1
    done
done