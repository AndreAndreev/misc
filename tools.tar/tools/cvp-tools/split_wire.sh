#!/bin/sh

if [ "$#" -lt 2 ]; then
    echo "Usage: $0 [File path of wire file] [Output directory] < -format: optional>"
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "Wire file $1 does not exist"
    exit 1
fi

if [ ! -d "$2" ]; then
    echo "Output directory does not exist, creating"
    mkdir -p "$2"
fi

let i=0
cat "$1" | while read line; do
    if [ -z "$line" ]; then
        continue
    fi
    prefix=in
    outbound=`echo "$line" | fgrep ":outboundTransaction"`
    if [ -n  "$outbound" ]; then
        prefix=out
    fi

    # strip out log crap and format
    line=`echo "$line" | sed 's/.*DT_WIRE_LOG\]\ //'`
    echo -e "$line" > "$2/$prefix-$i.txt"
    if [ -n "$3" ] && [ "$3" = "-format" ]; then
        sed -i 's/(/\n(/g' "$2/$prefix-$i.txt"
    fi
    let i=i+1
done