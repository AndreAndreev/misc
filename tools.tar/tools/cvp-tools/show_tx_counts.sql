SET PAGESIZE 50

select * from 
(
	select '100 raw' as TX_TYPE, count(1) as TX_COUNT from tx_100_raw
	union
	select '100 resolved', count(1) from tx_100_resolved
	union
	select '100 processed', count(1) from tx_100_processed
	union
	select '110 raw', count(1) from tx_110_raw
	union
	select '110 resolved', count(1) from tx_110_resolved
	union
	select '110 processed', count(1) from tx_110_processed
	union
	select '120 raw', count(1) from tx_120_raw
	union
	select '120 resolved', count(1) from tx_120_resolved
	union
	select '120 processed', count(1) from tx_120_processed
	union
	select '130 raw', count(1) from tx_130_raw
	union
	select '130 resolved', count(1) from tx_130_resolved
	union
	select '130 processed', count(1) from tx_130_processed
) order by TX_TYPE;
exit;
