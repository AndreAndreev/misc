#!/bin/sh

## This script takes two parameters:
#  1. name of DB properties file, correlated with instance name
#  2. location of public key in pem format, e.g. /home/osboxes/secureKey/secure_pub.pem
#  Script will connect to workflow schema and incode CREDENTIALS column values in ACCOUNT_DATASOURCE table
##


if [ "$#" -ne 2 ] || [ "$1" == "--help" ]; then
    echo "Usage: $0 INSTANCE_NAME, $1 PATH_TO_PUBLIC_KEY_FILE"
    exit 1
fi



if [ -r "$HOME/dbscript/$1_properties.sh" ]; then
        echo "Found instance properties file. Will source it"
        . "$HOME/dbscript/$1_properties.sh"
        else
        echo "Not found instance properties file: $HOME/dbscript/$1_properties.sh"
        exit 1
fi

RETVAL=`sqlplus -s $dbscript_workflow_schema/$dbscript_workflow_password@$dbscript_ora_tns <<EOF
set heading OFF termout ON trimout ON feedback OFF
set pagesize 0

select USERNAME || ',' || CREDENTIALS AS CREDS from ACCOUNT_DATASOURCE;

exit;
EOF`

ERROR_CODE=$?

if [ $ERROR_CODE != 0 ]
then
  echo "There are some errors. ErrorCode: $ERROR_CODE";
else
  rm -f updateTable.sql

  echo "${RETVAL}" |while read line
  do
    user_creds=($(echo "$line" | sed 's/,/ /g'))

    u_name=${user_creds[0]}
    u_password=${user_creds[1]}

    echo $u_password | openssl rsautl -pubin -keyform pem -inkey $2 -encrypt -out user_password.dat
    encrypted_password=`openssl enc -base64 -A -in user_password.dat`

    echo "UPDATE ACCOUNT_DATASOURCE SET CREDENTIALS='$encrypted_password' WHERE USERNAME='$u_name';" >> updateTable.sql
  done

  echo "COMMIT;" >> updateTable.sql
  echo "EXIT;" >> updateTable.sql

  sqlplus "$dbscript_workflow_schema/$dbscript_workflow_password@$dbscript_ora_tns" @updateTable.sql
fi