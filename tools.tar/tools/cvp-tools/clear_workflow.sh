#!/bin/sh

if [ "$#" -ne 1 ] || [ "$1" == "--help" ] || [ -z "`echo $1 | grep 'bh[0-9]\{4\}$'`" ] ; then
	echo "Usage: $0 bhXXXX"
	exit 1
fi

script_path=`ps aux | grep "/bin/sh $0" | grep -m 1 $0 | awk '{print $12}'`
script_dir=`dirname "$script_path"`

if [ -z "script_dir" ]; then
	echo "Cannot determine the script path. Getting out"
	exit 1
fi

WORKFLOW=workflow
unset http_proxy no_proxy
command=`echo sqlplus \'$WORKFLOW/$WORKFLOW\!\!@localhost:1521/xe\'`
eval $command "@$script_dir/clear_workflow.sql" $1
