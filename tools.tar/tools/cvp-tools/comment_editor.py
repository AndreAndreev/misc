#!/usr/bin/python

import sys
from Tkinter import *
import tkMessageBox as messagebox

def submitted():
    print("Submit pressed")
    submitted_comment = comment_text.get("1.0", "end-1c")
    if submitted_comment == comment:
        messagebox.showwarning("Warning", "You have not modified the commit. The commit will be aborted")
    else:
        with open(file_path, "w") as f:
            f.write("Branch: " + branch + " -- " + submitted_comment)
    sys.exit(0)

if len(sys.argv) < 2:
    print "File name not specified"
    sys.exit(1)
  
file_path=sys.argv[1]
file_obj = open(file_path, 'r')

comment = ''
branch = None
with open(file_path) as f:
    for line in f:
        if line.startswith("Branch:"):
            words = line.split()
            branch = words[1]
        else:
            comment = comment +  line

if branch is None:
    print "Could not parse branch"
    branch = "Unknown"

row = 0
root = Tk()
root.title("Comment Editor")

frame = Frame(root)

branch_value = StringVar()
branch_label=Label(frame, textvariable=branch_value)
branch_value.set("On branch: " + branch)
branch_label.grid(row=row, column=0, sticky=N+W)

row = row+1
scrollbar = Scrollbar(frame)
scrollbar.grid(row=row, column=1, sticky=N+S)

frame.grid_rowconfigure(row, weight=1)
frame.grid_columnconfigure(row, weight=1)
comment_text = Text(frame, padx=5, pady=5, wrap=WORD, yscrollcommand=scrollbar.set)
comment_text.insert(INSERT, comment)
comment_text.mark_set(INSERT, "%d.%d" % (0, 0))
comment_text.grid(row=row, column=0, sticky=N+S+E+W)
scrollbar.config(command=comment_text.yview)

row = row+1
frame.grid_rowconfigure(row, pad=5)
submit_button = Button(frame, text="Submit", command = submitted, padx=5, pady=5)
submit_button.grid(row=row, column=0)
frame.pack()

comment_text.focus_set()
root.mainloop()

