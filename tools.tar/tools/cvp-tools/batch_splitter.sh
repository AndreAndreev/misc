#!/bin/sh

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 [FILE_TO_SPLIT] [SPLIT_COUNT]"
    exit 1
fi

filename=$1

realm=`echo $filename | awk -F '_' '{print $1}'`

segment_000=000^BH9991^TEST^K1^09192011^112140^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^^^^^^^^^^^^^^^^^^^^
segment_999=999^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^0^^^^^^^^^^^^^^^^^^^^

declare -i count
declare -i claim_count
declare -i file_count

claim_count=$2
count=0
file_count=0

output_file=$realm"_"`printf "%014d\n" $file_count`".txt"
echo -e "$segment_000" > $output_file

while read -r line; do
    if [ -z "$line" ]; then
        continue
    fi

    segment=`echo $line | awk -F '^' '{print $1}'`
    if [ "$segment" = "000" ] || [ "$segment" = "999" ]; then
        continue
    fi

    header_segment=
    if [ "$segment" = "100" ] || [ "$segment" = "120" ] || [ "$segment" = "120" ]; then
        header_segment=true
    fi

    if [ -n "$header_segment" ]; then
        count=$count+1
        if [ $count -eq $claim_count ]; then
            echo -e "$segment_999" >> $output_file
            unix2dos $output_file

            count=0
            file_count=$file_count+1
            
            output_file=$realm"_"`printf "%014d\n" $file_count`".txt"
            echo -e "$segment_000" > $output_file
        fi
    fi
    
    if [ ! "$line" = "$segment_999" ]; then
        echo -e "$line" >> $output_file
    fi
done < $filename

# close out the file for remaining claims
echo -e "$segment_999" >> $output_file
unix2dos $output_file
