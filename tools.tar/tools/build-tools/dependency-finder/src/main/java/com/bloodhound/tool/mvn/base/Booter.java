/**********************************************************************
 * Copyright (c) 2016 Verisk Health
 * 
 * This source code is the property of Verisk Health and is strictly
 * confidential.  Neither the information contained in this file, nor
 * the know-how may be disclosed to a third party.  No parts of this
 * file may be reproduced, stored in a retrieval system, or transmitted
 * in any form or means (including electronic photocopying) without the
 * written permission of Verisk Health.
 * 
 * Any sample or example data contained in this source code are
 * fabricated and do not reflect any actual data that belongs to a
 * current or former Verisk Health. customer.
 * 
 *********************************************************************/
package com.bloodhound.tool.mvn.base;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.maven.repository.internal.MavenRepositorySystemUtils;
import org.eclipse.aether.DefaultRepositorySystemSession;
import org.eclipse.aether.RepositorySystem;
import org.eclipse.aether.RepositorySystemSession;
import org.eclipse.aether.repository.LocalRepository;
import org.eclipse.aether.repository.RemoteRepository;

/**
 * @author achatterjee
 *
 */
public class Booter
{
    public static RepositorySystem newRepositorySystem()
    {
        return ManualRepositorySystemFactory.newRepositorySystem();
    }

    public static DefaultRepositorySystemSession newRepositorySystemSession(RepositorySystem system,
            String localRepoDir)
    {
        DefaultRepositorySystemSession session = MavenRepositorySystemUtils.newSession();
        
        LocalRepository localRepo = new LocalRepository(localRepoDir);
        session.setLocalRepositoryManager(system.newLocalRepositoryManager(session, localRepo));
        
        session.setTransferListener(new ConsoleTransferListener());
        session.setRepositoryListener(new ConsoleRepositoryListener());

        // uncomment to generate dirty trees
        // session.setDependencyGraphTransformer( null );

        return session;
    }

    public static List<RemoteRepository> newRepositories(RepositorySystem system, RepositorySystemSession session,
            String remoteRepoUrl)
    {
        return new ArrayList<RemoteRepository>(
                Arrays.asList(new RemoteRepository.Builder("verscend", "default", remoteRepoUrl).build()));
    }
}
