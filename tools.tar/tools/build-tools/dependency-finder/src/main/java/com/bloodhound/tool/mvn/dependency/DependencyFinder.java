/**********************************************************************
 * Copyright (c) 2012 Verisk Health
 * 
 * This source code is the property of Verisk Health and is strictly
 * confidential.  Neither the information contained in this file, nor
 * the know-how may be disclosed to a third party.  No parts of this
 * file may be reproduced, stored in a retrieval system, or transmitted
 * in any form or means (including electronic photocopying) without the
 * written permission of Verisk Health.
 * 
 * Any sample or example data contained in this source code are
 * fabricated and do not reflect any actual data that belongs to a
 * current or former Verisk Health. customer.
 * 
 *********************************************************************/
package com.bloodhound.tool.mvn.dependency;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author achatterjee
 * 
 */
public class DependencyFinder
{
    private Map<String, DependencyNode> dependencyTree = new HashMap<String, DependencyNode>();
    private Repository repository;
    private String repositoryUrl;
    private static final Log LOGGER = LogFactory.getLog(DependencyFinder.class);

    private static final String COMMAND_LIST_TREE = "print-tree";
    private static final String COMMAND_DEPENDENCY_REPORT = "dependency-report";

    private static final String OPTION_ARTIFACT = "artifact";
    private static final String OPTION_HELP = "help";
    private static final String OPTION_COMMAND = "command";
    private static final String OPTION_SORT = "sort";
    private static final String OPTION_REPO_URL = "repository";

    private static final String[] DEPENDENCY_INCLUDES = { "com.bloodhound", "edi-beans", "com.verisk", "com.vhpad",
            "com.verscend" };

    public DependencyFinder(String repositoryUrl)
    {
        this.repositoryUrl = repositoryUrl;
    }

    public void init()
    {
        repository = new Repository(repositoryUrl, System.getProperty("user.home") + "/.m2/repository");
        repository.init();
    }

    private boolean isIncluded(String artifactId)
    {
        for (String e : DEPENDENCY_INCLUDES)
        {
            if (artifactId.startsWith(e))
            {
                return true;
            }
        }

        return false;
    }

    public void addToDependencyTree(String parentDependency, String dependency)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Adding dependency " + parentDependency + "->" + dependency);
        }

        try
        {
            DependencyNode node = dependencyTree.get(dependency);
            if (node == null)
            {
                node = new DependencyNode();
                dependencyTree.put(dependency, node);

                if (isIncluded(dependency))
                {
                    List<String> childDependencies = repository.listDependencies(dependency);
                    for (String childDependency : childDependencies)
                    {
                        node.getChildren().add(childDependency);
                        addToDependencyTree(dependency, childDependency);
                    }
                }
            }

            if (parentDependency != null)
            {
                node.getParents().add(parentDependency);
            }
        }
        catch (Exception e)
        {
            LOGGER.warn("Exception occured while processing dependency " + dependency, e);
        }
    }

    public void setRepository(Repository repository)
    {
        this.repository = repository;
    }

    public void printTree()
    {
        for (Entry<String, DependencyNode> entry : dependencyTree.entrySet())
        {
            String dependency = entry.getKey();
            DependencyNode info = entry.getValue();
            printNodeInfo(dependency, info);
        }
    }

    private void printNodeInfo(String dependency, DependencyNode info)
    {
        StringBuilder builder = new StringBuilder(
                "\n\n" + dependency + "\n---------------------------------------------------\n");
        for (String parent : info.getParents())
        {
            builder.append("\tParent: " + parent + "\n");
        }

        for (String child : info.getChildren())
        {
            builder.append("\tChild: " + child + "\n");
        }

        LOGGER.info(builder.toString());
    }

    private void listAffected(Collection<String> list, String dependency)
    {
        DependencyNode info = dependencyTree.get(dependency);
        if (info == null)
        {
            LOGGER.warn("Dependency " + dependency + " not found");
            return;
        }

        for (String parent : info.getParents())
        {
            list.add(parent + " : " + dependency);
            listAffected(list, parent);
        }

        return;
    }

    public void printAffected(String artifact, boolean sort)
    {
        Set<String> set = new LinkedHashSet<String>();

        List<String> artifacts = findArtifact(artifact);
        for (String a : artifacts)
        {
            listAffected(set, a);
        }

        if (set.size() > 0)
        {
            ArrayList<String> list = new ArrayList<String>(set);
            if (sort)
            {
                Collections.sort(list);
            }

            StringBuilder builder = new StringBuilder("Following artifacts are affected by changes to " + artifact
                    + "\n-----------------------------------------------");
            int index = 0;
            for (String e : list)
            {
                builder.append("\n\t(" + ++index + ") " + e);
            }

            LOGGER.info(builder.toString());
        }
    }

    private List<String> findArtifact(String nameStartingWith)
    {
        List<String> result = new ArrayList<String>();
        for (String artifact : dependencyTree.keySet())
        {
            if (artifact.startsWith(nameStartingWith))
            {
                result.add(artifact);
            }
        }

        return result;
    }

    private static void printUsage(Options options, OutputStream os)
    {
        HelpFormatter formatter = new HelpFormatter();
        PrintWriter writer = new PrintWriter(os);
        formatter.printHelp("java -jar dependencyFinder.jar OPTIONS... ARTIFACTS...", options);
        writer.close();
    }

    private static CommandLine parseCli(Options options, String[] args) throws ParseException
    {
        CommandLineParser parser = new DefaultParser();
        return parser.parse(options, args);
    }

    public static void main(String[] args) throws Exception
    {
        Options options = createOptions();
        if (args.length == 0 || args[0].equals("--" + OPTION_HELP))
        {
            printUsage(options, System.out);
            System.exit(0);
        }

        CommandLine commandLine = null;
        try
        {
            commandLine = parseCli(options, args);
        }
        catch (ParseException e)
        {
            System.err.println("Error parsing argument(s) - " + e.getMessage());
            printUsage(options, System.err);
            System.exit(1);
        }

        String repository = commandLine.getOptionValue(OPTION_REPO_URL);
        if (repository == null)
        {
            repository = "http://build/nexus/content/groups/public/";
        }
        else if (repository.equals("offline"))
        {
            repository = null;
        }

        DependencyFinder finder = new DependencyFinder(repository);
        finder.init();

        String[] rest = commandLine.getArgs();
        for (String dependency : rest)
        {
            finder.addToDependencyTree(null, dependency);
        }

        String command = commandLine.getOptionValue(OPTION_COMMAND);
        if (command == null)
        {
            command = COMMAND_DEPENDENCY_REPORT;
        }

        if (command.equals(COMMAND_LIST_TREE))
        {
            finder.printTree();
        }
        else if (command.equals(COMMAND_DEPENDENCY_REPORT))
        {
            String artifact = commandLine.getOptionValue(OPTION_ARTIFACT);
            if (artifact == null)
            {
                throw new Exception("The artifact option must be specified");
            }

            boolean sort = commandLine.hasOption(OPTION_SORT);

            finder.printAffected(artifact, sort);
        }
        else
        {
            throw new Exception("Unknown command " + command);
        }
    }

    private static Options createOptions()
    {
        Options options = new Options();

        Option option = new Option(OPTION_HELP, false, "Prints usage and exits");
        options.addOption(option);

        option = new Option(OPTION_ARTIFACT, true,
                "Name of the artifact to look for. The string can only contain the group and the artifact id,"
                        + " version number is optional." + " Applicable only with the " + COMMAND_LIST_TREE
                        + " command");
        options.addOption(option);

        option = new Option(OPTION_COMMAND, true,
                "Command to run [" + COMMAND_LIST_TREE + ", " + COMMAND_DEPENDENCY_REPORT + "]");
        options.addOption(option);

        option = new Option(OPTION_SORT, false, "Use this option to specify if you want the output sorted."
                + " Applicable only with the " + COMMAND_LIST_TREE + " command");
        options.addOption(option);

        option = new Option(OPTION_REPO_URL, true, "Use this option to specify the URL of the Maven repository."
                + " You can specify the URL as 'offline' if you want to use your local repository");
        options.addOption(option);

        return options;
    }
}
