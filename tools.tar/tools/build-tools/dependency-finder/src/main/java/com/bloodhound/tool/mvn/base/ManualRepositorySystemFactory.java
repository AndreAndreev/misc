/**********************************************************************
 * Copyright (c) 2016 Verisk Health
 * 
 * This source code is the property of Verisk Health and is strictly
 * confidential.  Neither the information contained in this file, nor
 * the know-how may be disclosed to a third party.  No parts of this
 * file may be reproduced, stored in a retrieval system, or transmitted
 * in any form or means (including electronic photocopying) without the
 * written permission of Verisk Health.
 * 
 * Any sample or example data contained in this source code are
 * fabricated and do not reflect any actual data that belongs to a
 * current or former Verisk Health. customer.
 * 
 *********************************************************************/
package com.bloodhound.tool.mvn.base;

import org.apache.maven.repository.internal.MavenRepositorySystemUtils;
import org.eclipse.aether.RepositorySystem;
import org.eclipse.aether.connector.basic.BasicRepositoryConnectorFactory;
import org.eclipse.aether.impl.DefaultServiceLocator;
import org.eclipse.aether.spi.connector.RepositoryConnectorFactory;
import org.eclipse.aether.spi.connector.transport.TransporterFactory;
import org.eclipse.aether.transport.file.FileTransporterFactory;
import org.eclipse.aether.transport.http.HttpTransporterFactory;

/**
 * @author achatterjee
 *
 */
public class ManualRepositorySystemFactory
{
    public static RepositorySystem newRepositorySystem()
    {
        DefaultServiceLocator locator = MavenRepositorySystemUtils.newServiceLocator();
        locator.addService( RepositoryConnectorFactory.class, BasicRepositoryConnectorFactory.class );
        locator.addService( TransporterFactory.class, FileTransporterFactory.class );
        locator.addService( TransporterFactory.class, HttpTransporterFactory.class );

        locator.setErrorHandler( new DefaultServiceLocator.ErrorHandler()
        {
            @Override
            public void serviceCreationFailed( Class<?> type, Class<?> impl, Throwable exception )
            {
                exception.printStackTrace();
            }
        } );

        return locator.getService( RepositorySystem.class );
    }
}
