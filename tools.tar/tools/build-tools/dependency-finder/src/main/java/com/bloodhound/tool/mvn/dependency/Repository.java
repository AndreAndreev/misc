/**********************************************************************
 * Copyright (c) 2012 Verisk Health
 * 
 * This source code is the property of Verisk Health and is strictly
 * confidential.  Neither the information contained in this file, nor
 * the know-how may be disclosed to a third party.  No parts of this
 * file may be reproduced, stored in a retrieval system, or transmitted
 * in any form or means (including electronic photocopying) without the
 * written permission of Verisk Health.
 * 
 * Any sample or example data contained in this source code are
 * fabricated and do not reflect any actual data that belongs to a
 * current or former Verisk Health. customer.
 * 
 *********************************************************************/
package com.bloodhound.tool.mvn.dependency;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.aether.DefaultRepositorySystemSession;
import org.eclipse.aether.RepositorySystem;
import org.eclipse.aether.artifact.Artifact;
import org.eclipse.aether.artifact.DefaultArtifact;
import org.eclipse.aether.collection.DependencyCollectionException;
import org.eclipse.aether.graph.Dependency;
import org.eclipse.aether.graph.DependencyNode;
import org.eclipse.aether.graph.DependencyVisitor;
import org.eclipse.aether.resolution.ArtifactDescriptorException;
import org.eclipse.aether.resolution.ArtifactDescriptorRequest;
import org.eclipse.aether.resolution.ArtifactDescriptorResult;
import org.eclipse.aether.resolution.DependencyResolutionException;
import org.eclipse.aether.util.graph.manager.DependencyManagerUtils;
import org.eclipse.aether.util.graph.transformer.ConflictResolver;

import com.bloodhound.tool.mvn.base.Booter;

/**
 * @author achatterjee
 * 
 */
public class Repository
{
    private static final Log LOGGER = LogFactory.getLog(Repository.class);

    private RepositorySystem system;
    private DefaultRepositorySystemSession session;

    private String remoteRepoUrl;

    private String localRepoUrl;

    public Repository(String remoteRepoUrl, String localRepoUrl)
    {
        this.remoteRepoUrl = remoteRepoUrl;
        this.localRepoUrl = localRepoUrl;
    }

    public void init()
    {
        system = Booter.newRepositorySystem();

        session = Booter.newRepositorySystemSession(system, localRepoUrl);
        session.setOffline(remoteRepoUrl == null);

        session.setConfigProperty(ConflictResolver.CONFIG_PROP_VERBOSE, true);
        session.setConfigProperty(DependencyManagerUtils.CONFIG_PROP_VERBOSE, true);
    }

    public List<String> listDependencies(String coords)
            throws ArtifactDescriptorException, DependencyCollectionException, DependencyResolutionException
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Listing dependencies for : " + coords);
        }

        List<String> result = new ArrayList<String>();
        DefaultArtifact artifact = new DefaultArtifact(coords);
        
        try
        {
            ArtifactDescriptorRequest request = new ArtifactDescriptorRequest();
            request.setArtifact(artifact);

            if (remoteRepoUrl != null)
            {
                request.setRepositories(Booter.newRepositories(system, session, remoteRepoUrl));
            }

            ArtifactDescriptorResult artifactResult = system.readArtifactDescriptor(session, request);
            List<Dependency> dependencies = artifactResult.getDependencies();
            for (Dependency dependency : dependencies)
            {
                result.add(formatArtifact(dependency.getArtifact()));
            }
        }
        catch (ArtifactDescriptorException e)
        {
            LOGGER.warn(e);
        }
        
        return result;
    }

    private String formatArtifact(Artifact a)
    {
        return a.getGroupId() + ":" + a.getArtifactId() + ":" + a.getVersion();
    }

    class ListDependencyVisitor implements DependencyVisitor
    {
        private List<String> list = new ArrayList<String>();

        @Override
        public boolean visitEnter(DependencyNode node)
        {
            list.add(formatArtifact(node.getArtifact()));
            return false;
        }

        @Override
        public boolean visitLeave(DependencyNode node)
        {
            return false;
        }

        public List<String> getList()
        {
            return list;
        }
    }
}
