package com.bloodhound.tool.mvn.dependency;

import java.util.HashSet;
import java.util.Set;

public class DependencyNode
{
    private Set<String> parents = new HashSet<String>();
    private Set<String> children = new HashSet<String>();

    public Set<String> getParents()
    {
        return parents;
    }

    public Set<String> getChildren()
    {
        return children;
    }
}
