/**********************************************************************
 * Copyright (c) 2016 Verisk Health
 * 
 * This source code is the property of Verisk Health and is strictly
 * confidential.  Neither the information contained in this file, nor
 * the know-how may be disclosed to a third party.  No parts of this
 * file may be reproduced, stored in a retrieval system, or transmitted
 * in any form or means (including electronic photocopying) without the
 * written permission of Verisk Health.
 * 
 * Any sample or example data contained in this source code are
 * fabricated and do not reflect any actual data that belongs to a
 * current or former Verisk Health. customer.
 * 
 *********************************************************************/
package com.bloodhound.tool.mvn.base;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.aether.AbstractRepositoryListener;
import org.eclipse.aether.RepositoryEvent;

/**
 * @author achatterjee
 *
 */
public class ConsoleRepositoryListener extends AbstractRepositoryListener
{
    private static final Log LOGGER = LogFactory.getLog(ConsoleRepositoryListener.class);
    
    public void artifactDeployed(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Deployed " + event.getArtifact() + " to " + event.getRepository());
    }

    public void artifactDeploying(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Deploying " + event.getArtifact() + " to " + event.getRepository());
    }

    public void artifactDescriptorInvalid(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug(
                "Invalid artifact descriptor for " + event.getArtifact() + ": " + event.getException().getMessage());
    }

    public void artifactDescriptorMissing(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Missing artifact descriptor for " + event.getArtifact());
    }

    public void artifactInstalled(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Installed " + event.getArtifact() + " to " + event.getFile());
    }

    public void artifactInstalling(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Installing " + event.getArtifact() + " to " + event.getFile());
    }

    public void artifactResolved(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Resolved artifact " + event.getArtifact() + " from " + event.getRepository());
    }

    public void artifactDownloading(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Downloading artifact " + event.getArtifact() + " from " + event.getRepository());
    }

    public void artifactDownloaded(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Downloaded artifact " + event.getArtifact() + " from " + event.getRepository());
    }

    public void artifactResolving(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Resolving artifact " + event.getArtifact());
    }

    public void metadataDeployed(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Deployed " + event.getMetadata() + " to " + event.getRepository());
    }

    public void metadataDeploying(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Deploying " + event.getMetadata() + " to " + event.getRepository());
    }

    public void metadataInstalled(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Installed " + event.getMetadata() + " to " + event.getFile());
    }

    public void metadataInstalling(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Installing " + event.getMetadata() + " to " + event.getFile());
    }

    public void metadataInvalid(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Invalid metadata " + event.getMetadata());
    }

    public void metadataResolved(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Resolved metadata " + event.getMetadata() + " from " + event.getRepository());
    }

    public void metadataResolving(RepositoryEvent event)
    {
        if (LOGGER.isDebugEnabled()) LOGGER.debug("Resolving metadata " + event.getMetadata() + " from " + event.getRepository());
    }
}
