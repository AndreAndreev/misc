The dependency-finder tools allows developers/release-managers to identify the repositories whose versions 
need to be updated when an artifact is modified and a new version is created for the artifact. Since we have too
many repositories, this is often difficult to find out especially if one does not have a detailed understanding of
system and the repositories. This tool will help with that. 

The tool is not completed yet, have limitations and may have bugs. So, use it for guidance purposes only. One notable
limitation is that it cannot scan Maven 1 projects and we have a few remaining projects.


To build from sources:
----------------------
mvn install

To run:
-------
cd target

# prints usage information
java -jar dependency-finder-exe.jar


# Example: What dependencies are affected if I make a change to the com.bloodhound:metrics:metrics-platform artifacts 
java -jar dependency-finder-exe.jar \ 
    -artifact com.bloodhound.metrics:metrics-platform \
    -command dependency-report \
    com.veriskhealth.pad.cvp.rtn:rtn-boot:RTN-SNAPSHOT \
    com.bloodhound.socket-bridge:socket-bridge-server:SOCKET-SNAPSHOT \
    com.bloodhound.bridge-cli:bridge-cli:BRGCLI-SNAPSHOT \
    edi-beans:edi-pipeline:EDIBEANS-SNAPSHOT \
    com.veriskhealth.pad:web-services-frontend-ear:WS-SNAPSHOT \
    com.veriskhealth.pad:spring-deployer-service:SF-SNAPSHOT
