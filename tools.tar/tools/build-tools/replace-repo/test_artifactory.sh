#!/bin/sh

function run_maven {
	 mvn clean dependency:tree install > ~/build.log
         if [ $? != 0 ];then
                 echo " The maven build fails for repository  $line">> ~/errorLog
                 figlet " $line ">> ~/global_build.log
                 cat ~/build.log >> ~/global_build.log
         fi 
}

output_dir=repo_work

if [ ! -z "$2" ]; then
        output_dir=$2
fi
echo "Output directory is $output_dir"

rm -rf "$output_dir"
mkdir "$output_dir"
cd "$output_dir"

list_file=repo
if [ ! -z "$1" ]; then
        list_file=$1
fi
echo "Repository list file is $list_file"

for line in `cat "../$list_file"`; do
	echo "Start of loop In `pwd`"
        echo "Working on repository $line"
        git clone ssh://git@bamboo.hcinsight.net:7999/vpa/$line	 
        if [ $? = 0 ]; then
                cd $line
                git checkout develop
                echo "Inside loop `pwd`"
                flist=`find . -name pom.xml`
                if [ ! -z "$flist" ]; then
			top_level_pom=`find . -maxdepth 1 -name pom.xml`
			if [ ! -z "$top_level_pom" ]; then
				run_maven	
			else
				grep "<module>" `find . -name pom.xml` -l | awk -F '/' '{print $2}' > package
				if [ -s package ] ; then
					cd `cat package`		
					run_maven
	 				cd ..
				fi
			fi
                fi
                cd ..
        else
               echo "git clone failed $line">> ~/errorLog
		
        fi
	echo "End of loop In `pwd`"
done


