#!/bin/sh

output_dir=repo_work
if [ ! -z "$2" ]; then
	output_dir=$2	
fi
echo "Output directory is $output_dir"

rm -rf "$output_dir"
mkdir "$output_dir"
cd "$output_dir"

list_file=repo
if [ ! -z "$1" ]; then
	list_file=$1
fi
echo "Repository list file is $list_file"

for line in `cat "../$list_file"`; do
        echo "Working on repository $line"
	git clone ssh://git@bamboo.hcinsight.net:7999/vpa/$line
	if [ $? = 0 ]; then
		cd $line
		git checkout develop
		echo "In `pwd`"
		flist=`find . -name pom.xml`
		if [ ! -z "$flist" ]; then
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:snapshotRepository/_:url" -v '${cvp.snapshots.url}' $flist
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:snapshotRepository/_:id" -v 'deploy.repo.snap' $flist
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:snapshotRepository/_:name" -v 'CVP Snapshots Repository' $flist
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:repository/_:name" -v 'CVP Releases Repository' $flist
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:repository/_:id" -v 'deploy.repo.rel' $flist
			xmlstarlet ed --inplace --pf -u "/_:project/_:distributionManagement/_:repository/_:url" -v '${cvp.releases.url}' $flist
			git add --all
			git commit -m "Changed the maven repository location"
			git push origin develop
			if [ $? != 0 ];then
				echo " git push failed $line" >> ~/errorLog
			fi
		fi
	        cd ..
	else
               echo "git clone failed $line" >> ~/errorLog
	fi
done
