#!/bin/sh

if [ -z "$GIT_HOME" ]; then
  export GIT_HOME=$HOME/git
fi

cp -p -i $GIT_HOME/tools/vm-tools/.bashrc $HOME/
cp -p -i $GIT_HOME/tools/vm-tools/.bash_profile $HOME/
touch $HOME/env-override.sh; chmod +x $HOME/env-override.sh

if [ -r  $GIT_HOME/maven-config/settings.xml ]; then
    if [ -h $HOME/.m2/settings.xml ]; then
        rm $HOME/.m2/settings.xml
    elif [ -f $HOME/.m2/settings.xml ]; then
        mv $HOME/.m2/settings.xml $HOME/.m2/settings.xml.bak
    fi

    mkdir -p $HOME/.m2
    ln -s $GIT_HOME/maven-config/settings.xml $HOME/.m2/settings.xml
fi

echo "Log out and log back in for the changes to take effect"

