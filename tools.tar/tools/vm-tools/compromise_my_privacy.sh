#!/bin/sh
sudo cp -i *.cer /etc/pki/ca-trust/source/anchors/
sudo update-ca-trust

echo "Log out and log back in to give up your privacy"

