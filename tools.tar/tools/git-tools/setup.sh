#!/bin/sh

mkdir -p ~/.git_template/hooks/
cp pre-commit ~/.git_template/hooks/
chmod +x ~/.git_template/hooks/*
touch ~/.gitmessage

git config --global init.templatedir '~/.git_template'
git config --global commit.template '~/.gitmessage'
git config --global core.editor "gedit"

echo "Run \"git init\" on the top directory of any repository for changes to take effect"
